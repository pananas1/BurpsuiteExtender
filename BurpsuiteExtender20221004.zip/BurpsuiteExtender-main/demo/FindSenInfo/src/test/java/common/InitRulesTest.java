package common;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InitRulesTest {

    @Test
    public void init(){

    }

}