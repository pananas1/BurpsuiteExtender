package utils;

/**
 * 定义一些常量
 * */
public class ConstantUtils {
    // 插件名称
    public static final String extenderName = "FindSenInfo";
    // 加载完插件的描述
    public static final String loadMessage = "load success";
}
