package common;

import com.alibaba.fastjson.JSONObject;

import java.util.List;
import java.util.Map;

public class Rules {
    private Map<String,Object> rules;

    public Map<String, Object> getRules() {
        return rules;
    }

    public void setRules(Map<String, Object> rules) {
        this.rules = rules;
    }
}
