package burp.yaml;

import java.util.List;
import burp.yaml.template.Rules;

public class RulesConfig {
    public List<Rules> rules;

    public void setRules(List<Rules> rules) {
        this.rules = rules;
    }
}
